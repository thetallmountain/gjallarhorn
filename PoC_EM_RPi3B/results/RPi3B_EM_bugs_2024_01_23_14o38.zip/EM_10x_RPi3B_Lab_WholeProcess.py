# -*- coding: utf-8 -*-
"""
Created on Wed Mar 22 16:36:52 2023

@author: jbarredo
"""

# LIBRARIES

from sklearn.metrics import *
import time
import datetime
import numpy as np
import shutil
import serial
import matplotlib.pyplot as plt
import csv
import pandas as pd
import pyvisa as visa
from lecroy3 import *
from numpy import loadtxt
from itertools import chain
from itertools import zip_longest
import seaborn as sns
import scipy.integrate as integrate
from sklearn.impute import SimpleImputer
import scipy.signal  
from scipy.stats import pearsonr, spearmanr
from numpy.random import normal
import random
import scipy.stats as stats
from numpy import exp
from numpy import savetxt
from scipy.fft import ifft, fft, rfft
from sklearn.neighbors import KernelDensity
from sklearn.neighbors import NearestNeighbors
from sklearn.covariance import EllipticEnvelope
from sklearn.covariance import MinCovDet
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import DBSCAN, HDBSCAN, OPTICS, MeanShift, estimate_bandwidth
from sklearn.utils.multiclass import unique_labels
from s_dbw import S_Dbw
import paramiko
from scp import SCPClient
import os.path
from scipy.signal import welch
from threading import *
import os
# import ffmpeg
import matplotlib.pyplot as plt
from scipy.stats import norm
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.lines import Line2D
from collections import Counter

import tkinter as tk
import tkinter.ttk as ttk
from tkinter.filedialog import *
import tkinter.filedialog as filedialog
from tkinter import StringVar
from tkinter import IntVar
from tkinter import LabelFrame
from tkinter import Label
from tkinter import Button
from tkinter import messagebox
from PIL import Image, ImageTk

# Configuración warnings
# ==============================================================================
import warnings
warnings.filterwarnings('ignore')

SHOW_GRAPH = False

device = 'RPi3B'
my_ip = "10.205.1.74"
# my_ip = "192.168.105.1"
n_fuzz=1

# date = "2024_01_03_11o36"
date = "2024_01_23_14o38"

calibration_path = '/home/atenea/ATENEA_Calibration_Clustering/input_files/calibration/'
entries_path = '/home/atenea/ATENEA_Calibration_Clustering/input_files/entries_lists/'
results_entries_path = '/home/atenea/ATENEA_Calibration_Clustering/input_files/entries_results/'
ffmpeg_path = '/home/atenea/ATENEA_Calibration_Clustering/input_files/ffmpeg_files/'
save_path = '/home/atenea/ATENEA_Calibration_Clustering/input_files/output_figs/'

# calibration_path = '/home/atenea/ATENEA_Calibration_Clustering/input_files/BBB_working/26_09_2023/'
# results_entries_path = calibration_path

# Inicializa un diccionario para el mapeo
mapeo_strings = {}

# Etiquetas de las clases
mapeo_bugs = {
    './Bugs_RPi4/SUT0101.bin': 'E0101',
    './Bugs_RPi4/SUT0102.bin': 'E0102',
    './Bugs_RPi4/SUT0103.bin': 'E0103',
    './Bugs_RPi4/SUT0104.bin': 'E0104',
    './Bugs_RPi4/SUT0105.bin': 'E0105',
    './Bugs_RPi4/SUT0106.bin': 'E0106',
    './Bugs_RPi4/SUT0201.bin': 'E0201',
    './Bugs_RPi4/SUT0202.bin': 'E0202',
    './Bugs_RPi4/SUT0203.bin': 'E0203',
    './Bugs_RPi4/SUT0204.bin': 'E0204',
    './Bugs_RPi4/SUT0205.bin': 'E0205',
    './Bugs_RPi4/SUT0206.bin': 'E0206',
    './Bugs_RPi4/SUT0207.bin': 'E0207',
    './Bugs_RPi4/SUT0208.bin': 'E0208',
    './Bugs_RPi4/SUT0209.bin': 'E0209',
    #'./Bugs_RPi4/SUT0210.bin': 'E0210',
    './Bugs_RPi4/SUT00I.bin': 'SUT00I',
    './Bugs_RPi4/SUT00F.bin': 'SUT00F'
}

# Etiquetas de las clases
# mapeo_bugs = {
#     './Bugs_RPi4/SUT00I.bin': 'SUT00I',
#     './Bugs_RPi4/SUT00I.bin': 'SUT00I',
#     './Bugs_RPi4/SUT00I.bin': 'SUT00I',
#     './Bugs_RPi4/SUT00I.bin': 'SUT00I',
#     './Bugs_RPi4/SUT00I.bin': 'SUT00I',
#     './Bugs_RPi4/SUT00I.bin': 'SUT00I',
#     './Bugs_RPi4/SUT00I.bin': 'SUT00I',
#     './Bugs_RPi4/SUT00I.bin': 'SUT00I',
#     './Bugs_RPi4/SUT00I.bin': 'SUT00I',
#     './Bugs_RPi4/SUT00I.bin': 'SUT00I',
#     './Bugs_RPi4/SUT00I.bin': 'SUT00I',
#     './Bugs_RPi4/SUT00I.bin': 'SUT00I',
#     './Bugs_RPi4/SUT00I.bin': 'SUT00I',
#     './Bugs_RPi4/SUT00I.bin': 'SUT00I',
#     './Bugs_RPi4/SUT00I.bin': 'SUT00I',
#     #'./Bugs_RPi4/SUT0210.bin': 'E0210',
#     './Bugs_RPi4/SUT00I.bin': 'SUT00I',
#     './Bugs_RPi4/SUT00F.bin': 'SUT00F'
# }

# VARIABLES FIJADAS PARA PRUEBAS
n_files = 3
# delta_t0 = -1
# epsilon0 = 0
# epsilon1 = 0
# command_OP = b'\xA0' 
pca_plot = 0
clust = 0
silh = 0

imp_model = 6

# GLOBAL PARAMETERS
gauss_dict = dict([(1, 0.682), (2, 0.954)])
val=1
input_signal = np.array([])
outlied_signal = np.array([])
robust_samples = np.array([])
pca_samples = np.array([])
silh_score = []
calinski_score = []
davies_score = []
sdbw_score = []
variance_score = []
variance_coefficient = []
max_n_components_pca = []
labels_array = []

from scipy.signal import convolve2d
from scipy.ndimage import filters

def apply_filter(input_signal, filter_type, filter_params):
  """
  Applies a noise reduction filter to a 1D signal.

  Args:
    input_signal: 1D array representing the signal.
    filter_type: String specifying the filter type ("mean" or "gaussian").
    filter_params: Dictionary containing filter parameters.

  Returns:
    The filtered signal (1D array).
  """
  if filter_type == "mean":
    window_size = filter_params["window_size"]
    # Pad the signal for border handling during filtering
    pad_width = (window_size - 1) // 2
    padded_signal = np.pad(input_signal, pad_width, mode='constant')
    # Define filter kernel (all ones for mean filter)
    filter_kernel = np.ones(window_size) / window_size
    # Apply convolution for filtering
    filtered_signal = np.convolve(padded_signal, filter_kernel, mode='same')
    return filtered_signal[pad_width:-pad_width]
  elif filter_type == "gaussian":
    sigma = filter_params["sigma"]
    # Use casting for compatibility
    filtered_signal = filters.gaussian_filter(input_signal.astype(np.float64), sigma=sigma).astype(input_signal.dtype)
    return filtered_signal
  else:
    raise ValueError("Unsupported filter type: {}".format(filter_type))


def get_class_name(obj):
    return type(obj).__name__

def robust_covariance(signal): # ETAPA 3
    detector = EllipticEnvelope(contamination=0.1)
    return detector.fit(signal).predict(signal)
    
def outlier_detection(kind):
    
    global n_samples
    global n_files
    global imp_model
    global outlied_signal
    # global fence_low
    # global fence_high
    
    outlied_signal = np.array([[[0 for z in range(np.shape(input_signal)[2])] for y in range(np.shape(input_signal)[1])] for x in range(np.shape(input_signal)[0])], dtype=float)
    n_it = np.shape(outlied_signal)[0]
    
    for i in range(n_it):
        quartile_threshold=50
        indice_25000_ceros = 0
            
        if i<2:
            ceros_por_fila = np.count_nonzero(input_signal[i] == 0, axis=1)
            # Encontrar el índice donde el número de ceros por fila es igual a 25000
            indice_25000_ceros = np.where(ceros_por_fila == n_samples)[0]            
            
        if i==1:
            quartile_threshold=5
        
        for j in range(np.shape(outlied_signal)[1]):
            
            if i==2 or (i<2 and j not in indice_25000_ceros):
    
                q1 = pd.DataFrame(input_signal[i][j]).quantile(0.25)[0]
                q3 = pd.DataFrame(input_signal[i][j]).quantile(0.75)[0]
                iqr = q3 - q1 #Interquartile range
                fence_low = q1 - (quartile_threshold*iqr)
                fence_high = q3 + (quartile_threshold*iqr)
                
                if imp_model == 2: # Mean imputation
                        outlied_signal[i][j] = input_signal[i][j].copy()
                        outlied_signal[i][j][(input_signal[i][j] <= fence_low)]=np.mean(outlied_signal[i][j])
                        outlied_signal[i][j][(input_signal[i][j] >= fence_high)]=np.mean(outlied_signal[i][j])       
                
                elif imp_model == 3: # Median imputation
                        outlied_signal[i][j] = input_signal[i][j].copy()
                        outlied_signal[i][j][(input_signal[i][j] <= fence_low)]=np.median(outlied_signal[i][j])
                        outlied_signal[i][j][(input_signal[i][j] >= fence_high)]=np.median(outlied_signal[i][j])      
                
                elif imp_model == 4: # LOCF
                        signal = pd.DataFrame(input_signal[i][j].copy().reshape(1,-1)).astype(float)
                        signal.T[(input_signal[i][j] <= fence_low)]=np.nan
                        signal.T[(input_signal[i][j] >= fence_high)]=np.nan
                        outlied_signal[i][j] = signal.T.fillna(method='bfill').T.to_numpy()
                    
                elif imp_model == 5: # NOCB
                        signal = pd.DataFrame(input_signal[i][j].copy().reshape(1,-1)).astype(float)
                        signal.T[(input_signal[i][j] <= fence_low)]=np.nan
                        signal.T[(input_signal[i][j] >= fence_high)]=np.nan
                        outlied_signal[i][j] = signal.T.fillna(method='ffill').T.to_numpy()
                       
                elif imp_model == 6: # Linear interpolation
                        signal = pd.DataFrame(input_signal[i][j].copy().reshape(1,-1)).astype(float)
                        signal.T[(input_signal[i][j] <= fence_low)]=np.nan
                        signal.T[(input_signal[i][j] >= fence_high)]=np.nan
                        outlied_signal[i][j] = signal.T.interpolate(method='linear').T.to_numpy()
    
                elif imp_model == 7: # Spline interpolation
                        signal = pd.DataFrame(input_signal[i][j].copy().reshape(1,-1)).astype(float)
                        signal.T[(input_signal[i][j] <= fence_low)]=np.nan
                        signal.T[(input_signal[i][j] >= fence_high)]=np.nan
                        outlied_signal[i][j] = signal.T.interpolate(method='spline').T.to_numpy()
                      
                else: # Zeroes imputation
                        outlied_signal[i][j] = input_signal[i][j].copy()
                        outlied_signal[i][j][(input_signal[i][j] <= fence_low)]=0
                        outlied_signal[i][j][(input_signal[i][j] >= fence_high)]=0  
                        
                outlied_signal[i][j] = outlied_signal[i][j].ravel()

        
    outlied_signal = [np.atleast_1d(np.asarray(x,dtype=np.int64)) for x in outlied_signal] 
    outlied_signal = np.array(outlied_signal, dtype=float)
        
def robust_covariance_procedure(kind):
    
    global n_files
    global n_traces
    global n_samples
    global outlied_signal
    global robust_samples

    robust_samples = np.array([[[0 for z in range(n_samples)] for y in range(n_traces)] for x in range(n_files)], dtype=object)
    
    for test in range(np.shape(outlied_signal)[0]):  
            if test < 2:
                # ELIMINO TRAZAS NULAS
                # Contar el número de ceros por fila
                ceros_por_fila = np.count_nonzero(outlied_signal[test] == 0, axis=1)
    
                # Encontrar el índice donde el número de ceros por fila es igual a 25000
                indice_25000_ceros = np.where(ceros_por_fila == n_samples)[0]
                # print("INDICE ",ceros_por_fila)
                
            for i in range(np.shape(outlied_signal)[1]):
                print(test, i)
                if test==2 or (test<2 and i not in indice_25000_ceros):
                    robust_samples[test][i] = robust_covariance(np.transpose(outlied_signal[test][i, np.newaxis])) # ETAPA 3
        
def pca_technique_application(kind):
    
    global n_traces
    global robust_samples
    global pca_samples
    global input_signal
    global max_n_components_pca
    global save_path
    
    # pca_samples = np.array([[0 for y in range(np.shape(input_signal)[2])] for x in range(np.shape(input_signal)[0]*np.shape(input_signal)[1])], dtype=object)
    # pca_samples = np.array([[0 for y in range(np.shape(outlied_signal)[2])] for x in range(np.shape(outlied_signal)[0]*np.shape(outlied_signal)[1])], dtype=object)
    pca_samples = np.array([[0 for y in range(np.shape(robust_samples)[2])] for x in range(np.shape(robust_samples)[0]*np.shape(robust_samples)[1])], dtype=float)
    # n_components = [np.shape(input_signal)[1] for x in range(3)]
    
    signal_name = ["OP signal", "NOP signal", "Bugs signal"]
       
    # PCA TRAINING
    datos = pd.DataFrame(np.transpose(robust_samples[2]))
    scaler = StandardScaler()
    data_rescaled = scaler.fit_transform(datos)
    pca = PCA().fit(data_rescaled)
    # pca = PCA().fit(datos)
    xi = np.arange(1, np.shape(robust_samples)[1]+1, step=1)
    y = np.cumsum(pca.explained_variance_ratio_)        
    #print(np.argwhere(y>=0.99))
    plt.rcParams["figure.figsize"] = (20,6)
    fig, ax = plt.subplots()
    plt.ylim(0.0,1.1)
    plt.plot(xi, y, marker='o', linestyle='--', color='b')
    plt.xlabel('Number of Components')
    plt.xticks(np.arange(1, np.shape(robust_samples)[2]+1, step=1), rotation=90) #change from 0-based array index to 1-based human-readable label
    plt.ylabel('Cumulative variance (%)')
    plt.title('The number of components needed to explain variance ({})' .format(kind))
    plt.axhline(y=0.95, color='r', linestyle='-')
    plt.text(0.5, 1, '95% cut-off threshold', color = 'red', fontsize=16)
    ax.grid(axis='x')
    plt.savefig(save_path + device + "_entries_list_" + date + "_PCA_{}" .format(kind))
    plt.show()
    # n_components[k] = np.argwhere(y>=0.95)[0]
    # Calculate the slope at each point (numerical differentiation)
    slope = np.diff(y) / np.diff(xi)
    
    # Find the indices where the slope decreases sharply while respecting the previous element
    sharp_slope_indices = []
    for i in range(1, len(slope)):
        if np.abs(slope[i] - slope[i - 1]) < 1e-4:  # (Adjust the threshold as needed)
            sharp_slope_indices.append(i)
            break
    
    if len(sharp_slope_indices)>0:
        n_components = sharp_slope_indices[0]+1
        
    plt.figure(dpi=100)
    plt.plot(xi, np.abs(np.gradient(y/(xi/n_traces),xi)))
    plt.axvline(x=n_components, color='r', linestyle='-')
    plt.title('Curve meaning absolute value of gradient of explained varience/(n_element/n_traces), for {}' .format(kind))
    plt.text(n_components, 0.1, n_components, color = 'red', fontsize=16)
    plt.savefig(save_path + device + "_entries_list_" + date + "_PCA_gradient_curve_{}" .format(kind))
    plt.show()
                
    # n_components = np.argmax(np.abs(np.gradient(y/(xi/n_traces),xi)))+1
    # max_n_components_pca = np.min(n_components)
    max_n_components_pca = sharp_slope_indices[0]+1
    # reshaped_robust_samples = np.array(robust_samples).reshape(np.shape(robust_samples)[0]*np.shape(robust_samples)[1],np.shape(robust_samples)[2])
    reshaped_robust_samples = np.array(robust_samples).reshape(np.shape(robust_samples)[0]*np.shape(robust_samples)[1],np.shape(robust_samples)[2])
   
    # ELIMINO TRAZAS NULAS
    # Contar el número de ceros por fila
    ceros_por_fila = np.count_nonzero(reshaped_robust_samples == 0, axis=1)

    # Encontrar el índice donde el número de ceros por fila es igual a 25000
    indice_25000_ceros = np.where(ceros_por_fila == n_samples)[0]
    
    reshaped_robust_samples = np.delete(reshaped_robust_samples, indice_25000_ceros, axis=0)
    
    # PCA APPLICATION TO BUGS
    print("Using {} components in PCA" .format(max_n_components_pca))
    # pca = PCA(n_components=max_n_components_pca, whiten=False).fit(reshaped_robust_samples)
    # pca = PCA(n_components=np.where(y>=0.99)[0][0]+2*cal_n_traces, whiten=False).fit(reshaped_robust_samples)
    pca = PCA(n_components=340+2*cal_n_traces, whiten=False).fit(reshaped_robust_samples)
    pca_samples = pca.transform(reshaped_robust_samples)

    # print("PCA explained variance ratio: ", pca.explained_variance_ratio_)
    # pca_samples = reshaped_robust_samples
     
def clustering_procedure(kind):
    
    global entries_path
    global entries_list
    global pca_samples
    global input_signal
    global labels_array
    global silh_score
    global calinski_score
    global davies_score
    global sdbw_score
    global variance_score
    global variance_coefficient
    global NOEXEC_samples
    global EXEC_samples
    global n_tests
    global instances
    global distances
    global y_pred
    # global y_mod
    global data
    global date
    global gauss_dict
    global val
    global entries_list
    global mapeo_strings
    global cal_n_traces
    global y_pred_changed
    
    #rangos = np.linspace(1, n_traces, n_traces) # NO SE PONE VENTANA=1 PORQUE LA DESV.TIPICA ES CERO, Y UNA VENTANA=2 ES MUY PEQUEÑA. SE NECESITAN MINIMO 3
    varianzas = np.array([np.nan for x in range(n_traces)])
    stop_index_vals = np.array([np.nan for x in range(n_traces)])
    stop_index = np.nan
    r = 0
    
    pca_samples_2 = np.copy(pca_samples)
    pca_samples = np.array([[0 for y in range(int(np.shape(pca_samples_2)[1]/2+1))] for x in range(np.shape(pca_samples_2)[0])], dtype=float)
    for i in range(np.shape(pca_samples)[0]):
        pca_samples[i] = np.abs(rfft(pca_samples_2[i]))
    
    stop_index = n_traces
    # for i in np.linspace(2, n_traces, n_traces):
    for i in range(1,2):
        print("Searching stop index for sliding window={}..." .format(int(i)))
        silh_score = [np.nan for x in range(n_traces)]
        calinski_score = np.array([np.nan for x in range(n_traces)])
        stop_calinski = np.array([[np.nan for y in range(n_traces)] for x in range(n_traces)])
        davies_score = [np.nan for x in range(n_traces)]
        sdbw_score = [np.nan for x in range(n_traces)]
        # variance_score = [np.nan for x in range(np.shape(pca_samples)[0]-2*n_traces)]
        labels_array = [[np.nan for y in range(2*cal_n_traces+n_traces)] for x in range(n_traces)]
        # stop_index = np.nan
        
        # backup_dist = 0
        # label = []
        # label2 = []
        # label3 = []
        
        # path = os.path.join(ffmpeg_path, "DBSCAN_" + date)
        # # os.mkdir(path)
        
        cons_values = int(i) # Number of considered values for slopes STOP
        max_nans = int(gauss_dict[val]*cons_values) # Number of NaN to stop the clustering
        
        # for index in range(1,n_traces+1):
        for index in range(n_traces,n_traces+1):
            # print("Elementos [ 0 :", index, "]")
        
            data = pca_samples[:(2*cal_n_traces+index)]
        
            instances = np.shape(data)[0]
            attributes = np.shape(data)[1]
            neighbors = NearestNeighbors(n_neighbors=n_tests).fit(data)
            distances, indices = neighbors.kneighbors(data)
            distances = np.sort(distances, axis=0)
            distances = distances[:, 1]
            eps = distances[instances - n_tests - 1]
        
            if n_tests == 0:
                eps = distances[round(instances * 0.99)]
        
            # DBSCAN
            min_samples = round(n_tests * 0.8)
        
            unique, counts = numpy.unique(entries_list[:index], return_counts=True)
            
            # from sklearn.cluster import KMeans, HDBSCAN
            # from sklearn.metrics import silhouette_score                        
            # db = KMeans(n_clusters=2)
            # y_pred = db.fit_predict(data)
            
            # from sklearn.mixture import GaussianMixture
            # # Instantiate and fit the NPMM model
            # gmm = GaussianMixture(n_components=2)
            # gmm.fit(data)
            # # Get cluster labels
            # y_pred = gmm.predict(data)
            
            # from sklearn.cluster import AgglomerativeClustering
            # # Instantiate and fit the HAC model
            # hac = AgglomerativeClustering(n_clusters=2, linkage='ward')
            # hac.fit(data)
            # # Get cluster labels
            # y_pred = hac.labels_
            
            # affinity propagation clustering
            from sklearn.datasets import make_classification
            from sklearn.cluster import AffinityPropagation
            # define the model
            db = AffinityPropagation(damping=0.5)
            # assign a cluster to each example
            y_pred = db.fit_predict(data)
            
            # db = DBSCAN(eps=eps, min_samples=1)
            
            # db = HDBSCAN(cluster_selection_epsilon=eps, min_samples=2, min_cluster_size=5)
            # y_pred = db.fit_predict(data)
            
            # bwth = estimate_bandwidth(data)
            # db = MeanShift(bandwidth=bwth)
            # y_pred = db.fit_predict(data)
            
            label3 = db.labels_
            labels_array[index-1] = db.labels_
        
            # Number of clusters in labels, ignoring noise if present.
            n_clusters_ = len(set(label3)) - (1 if -1 in label3 else 0)
            n_noise_ = list(label3).count(-1)
        
            # print("Estimated number of clusters: %d" % n_clusters_)
            # print("Estimated number of noise points: %d" % n_noise_)
            # print(label3)
        
            unique, counts = numpy.unique(y_pred, return_counts=True)
            #print(index, " DBSCAN CLUSTERS:", dict(zip(unique, counts)))
        
            #plotting the results: 
            # fig = plt.figure(figsize=(16,16), dpi=100)
            # ax = fig.add_subplot(projection='3d')
            # sc = ax.scatter(data[:n_traces,int(np.round(np.shape(pca_samples)[1]/2)-1)], data[:n_tr    aces,int(np.round(np.shape(pca_samples)[1]/2))], data[:n_traces,int(np.round(np.shape(pca_samples)[1]/2)+1)], zdir='y', c= y_pred[:n_traces], s=25, cmap    ='viridis', marker="*")
            # sc = ax.scatter(data[2*n_traces+1:,int(np.round(np.shape(pca_samples)[1]/2)-1)], data[2*n_t    races+1:,int(np.round(np.shape(pca_samples)[1]/2))], data[2*n_traces+1:,int(np.round(np.shape(pca_samples)[1]/2)+1)], zdir='y', c= y_pred[2*n    _traces+1:], s=25, cmap='viridis', marker="o")
            # # ax.view_init(elev=20., azim=-35, roll=0)
            # ax.set_xlabel('$X$', fontsize=20, rotation = 0)
            # ax.set_ylabel('$Y$', fontsize=20, rotation = 0)
            # ax.set_zlabel('$Z$', fontsize=20, rotation = 0)
            # # ax.legend(*sc.legend_elements(), title='Clusters')
            # plt.title("DBSCAN")        
            # plt.title("DBSCAN clustering considering {} elements" .format(2*n_traces+index))
            # plt.savefig("GUI_elements/DBSCAN_clust_results.png", bbox_inches='tight')
        
            num = str(index-1)
            if index < 10:
                num = '0' + num
            # plt.savefig(path + "/DBSCAN_clust_results_" + date + "_" + num + ".jpg", bbox_inches='tight', dpi=100)
            # plt.show()
        
            # Calculate Silhouette Score
            silh_score[index-1] = silhouette_score(data, db.labels_)
        
            # Calculate Calinski-Harabasz Score
            calinski_score[index-1] = calinski_harabasz_score(data, db.labels_)
        
            # Calculate Davies-Bouldin Score
            davies_score[index-1] = davies_bouldin_score(data, db.labels_)
        
            # Calculate S_Dbw Score
            sdbw_score[index-1] = S_Dbw(data, db.labels_, method='Halkidi', metric='euclidean')
        
            # # Calculate variance score
            # variance_score[index-1]=np.std(data, ddof=1)/np.mean(data)*100
        
            # x = np.linspace(2*cal_n_traces+1-cons_values+index, 2*cal_n_traces+index, cons_values)
            x = np.linspace(2*cal_n_traces+1, 2*cal_n_traces+index, index)
            
        #     # START SLIDING WINDOW
        #     if index>cons_values and np.isnan(stop_index_vals[r]):
        #         # print(x, calinski_score[index-cons_values:index])
        #         #  slopes = np.gradient(calinski_score[index-cons_values:index], x)
        #         slopes = np.gradient(calinski_score[:index], x)
        #         # if index % i == 0:
        #         #     fig = plt.figure(figsize=(16,16), dpi=100)
        #         #     plt.plot(slopes)
        #         #     plt.title("Gradient of Calinski-Harabasz score for a window of {} elements, from traces 0 to {}" .format(int(i), index))
        #         #     plt.show()
        #         stop_calinski = slopes.copy()
        #         stop_calinski[np.where(np.abs(slopes)>(np.abs(np.mean(np.abs(slopes))+val*np.std(np.abs(slopes)))))]=np.nan
        #         number_of_nans = np.count_nonzero(np.isnan(stop_calinski)) 
        #         #print("Varianza de la curva: {}" .format(np.std(calinski_score[index-cons_values:index])))
        #         if(number_of_nans>=max_nans):
        #             fig = plt.figure(figsize=(16,16), dpi=100)
        #             plt.plot(slopes, label = 'Gradient of Calinski-Harabasz score')
        #             plt.plot(calinski_score[:index], label = 'Calinski-Harabasz score')
        #             plt.title("Gradient of Calinski-Harabasz score for a window of {} elements, from traces 0 to {} ({})" .format(int(i), index, kind))
        #             plt.legend()
        #             plt.show()
                    
        #             stop_index_vals[r] = int(index - cons_values + 2)
        #             stop_labels = np.copy(labels_array[index-cons_values])
        #             varianzas[r] = np.std(calinski_score[index-cons_values:index])
        #             print("Stop index: {}; std_dev {}; window of {} elements considering the last {} traces" .format(int(stop_index_vals[r]), varianzas[r], int(i), index))
        #             # print(number_of_nans)
        #             break   
        # if np.isnan(stop_index_vals[r]):
        #     if r == n_traces:
        #         stop_index = int(n_traces)
        #         break
        # if np.isnan(stop_index_vals[r]) and r == n_traces:
        #     stop_index = n_traces
        #     print("No stop index found. Using n_traces")
        # # elif np.isnan(stop_index_vals[r]) and r < n_traces:
        # #     stop_index = int(stop_index_vals[np.argmin(varianzas[2:r])+2])
        # #     print("The final stop index is {}, using a sliding window of {} elements (Obtained through argmin method)" .format(stop_index, int(i)))
        # #     # Calcula los parámetros de la distribución normal ajustada a los datos
        # #     mu, std = norm.fit(calinski_score[:stop_index])
    
        # #     # Crea un histograma de los datos para representar la distribución normal
        # #     plt.hist(calinski_score[:stop_index], bins=50, density=True, alpha=0.6, color='g', label='Datos')
    
        # #     # Calcula la función de densidad de probabilidad de la distribución normal
        # #     xmin, xmax = plt.xlim()
        # #     x = np.linspace(xmin, xmax, 100)
        # #     p = norm.pdf(x, mu, std)
    
        # #     # Grafica la distribución normal
        # #     plt.plot(x, p, 'k', linewidth=2, label='Distribución Normal')
    
        # #     # Agrega puntos de datos al gráfico como un scatterplot
        # #     plt.scatter(calinski_score[:stop_index], np.zeros_like(calinski_score[:stop_index]), alpha=0.5, color='b', label='Puntos de Datos')
    
        # #     # Configura leyendas y etiquetas
        # #     plt.legend()
        # #     plt.xlabel('Valor')
        # #     plt.ylabel('Densidad de Probabilidad')
        # #     plt.title('Distribución Normal y Puntos de Datos')
        # #     plt.grid(True)
    
        # #     # Muestra el gráfico
        # #     plt.show()
            
        # #     number_entries_list = [mapeo_strings[valor] for valor in entries_list]
        # #     bugs_entries_list = [mapeo_bugs[valor] for valor in entries_list]
    
        # #     # Obtén las etiquetas únicas de ambos arrays
        # #     etiquetas_unicas_true = np.unique(bugs_entries_list)            
        # #     etiquetas_unicas_pred = np.unique(y_pred[2*cal_n_traces:stop_index])
            
        # #     # Crea una matriz de confusión manualmente
        # #     confus_matrix = np.zeros((len(etiquetas_unicas_true), len(etiquetas_unicas_pred)))
            
        # #     for true_label, pred_label in zip(bugs_entries_list, y_pred[2*cal_n_traces:stop_index]):
        # #         confus_matrix[np.where(etiquetas_unicas_true == true_label)[0][0],
        # #                       np.where(etiquetas_unicas_pred == pred_label)[0][0]] += 1
            
        # #     # CAMBIO NUMEROS POR CODIGOS DE ERROR
        # #     y_pred_changed = y_pred.astype(str)
        # #     for i in range(len(etiquetas_unicas_true)):
        # #         label = np.argmax(confus_matrix[i])
        # #         rep = len(np.where(confus_matrix[i] == np.max(confus_matrix[i]))[0])
        # #         for label in range(rep):
        # #             index = np.where(confus_matrix[i] == np.max(confus_matrix[i]))[0][label]
        # #             if type(etiquetas_unicas_pred[index]) == numpy.int64:
        # #                 y_pred_changed[y_pred==etiquetas_unicas_pred[index]]=etiquetas_unicas_true[i]       
                          
        # #     etiquetas_unicas_pred = np.unique(y_pred_changed[2*cal_n_traces:stop_index])
            
        # #     # Encontrar valores únicos en array_a_anadir que no están en array_referencia
        # #     valores_nuevos = np.setdiff1d(etiquetas_unicas_true, etiquetas_unicas_pred)
            
        # #     # Añadir los valores únicos al array original
        # #     etiquetas_unicas_pred = np.union1d(etiquetas_unicas_pred, valores_nuevos)
        # #     etiquetas_unicas_pred = np.roll(etiquetas_unicas_pred, -np.where(etiquetas_unicas_pred=='E0101')[0])
            
        # #     # Crea una matriz de confusión manualmente
        # #     confus_matrix = np.zeros((len(etiquetas_unicas_true), len(etiquetas_unicas_pred)))
            
        # #     for true_label, pred_label in zip(bugs_entries_list, y_pred_changed[2*cal_n_traces:stop_index]):
        # #         confus_matrix[np.where(etiquetas_unicas_true == true_label)[0][0],
        # #                       np.where(etiquetas_unicas_pred == pred_label)[0][0]] += 1
            
        # #     # Crea la visualización de la matriz de confusión con el número de instancias
        # #     plt.imshow(confus_matrix, cmap=plt.get_cmap('GnBu'), interpolation='nearest')
            
        # #     # Etiqueta los cuadrados con el número de instancias
        # #     for i in range(len(etiquetas_unicas_true)):
        # #         for j in range(len(etiquetas_unicas_pred)):
        # #             plt.text(j, i, str(int(confus_matrix[i, j])),
        # #                       ha="center", va="center", color="black")
            
        # #     plt.title('Matriz de Confusión for {} elements ({})' .format(stop_index, kind))
        # #     plt.colorbar()
            
        # #     # Etiqueta los ejes
        # #     plt.xticks(np.arange(len(etiquetas_unicas_pred)), etiquetas_unicas_pred)
        # #     plt.xticks(rotation=90)
        # #     plt.yticks(np.arange(len(etiquetas_unicas_true)), etiquetas_unicas_true)
            
        # #     # Etiquetas para los ejes
        # #     plt.xlabel('Etiquetas Predichas')
            
        # #     # Etiqueta para el eje y (en vertical)
        # #     plt.ylabel('Etiquetas Reales', rotation=90, verticalalignment='center')
            
        # #     plt.show()
        # #     break
        
        # elif r>1 and varianzas[r]/varianzas[r-1] >= 0.95:
        #     stop_index = index
        #     print("The final stop index is {}, using a sliding window of {} elements (Obtained through st_dev comparison)" .format(stop_index, int(i)))
            
        #     number_entries_list = [mapeo_strings[valor] for valor in entries_list]
        #     bugs_entries_list = [mapeo_bugs[valor] for valor in entries_list]
    
        #     # Obtén las etiquetas únicas de ambos arrays
        #     etiquetas_unicas_true = np.unique(bugs_entries_list)            
        #     etiquetas_unicas_pred = np.unique(y_pred[2*cal_n_traces:2*cal_n_traces+stop_index])
            
        #     # Crea una matriz de confusión manualmente
        #     confus_matrix = np.zeros((len(etiquetas_unicas_true), len(etiquetas_unicas_pred)))
                        
        #     for true_label, pred_label in zip(bugs_entries_list, y_pred[2*cal_n_traces:2*cal_n_traces+stop_index]):
        #         confus_matrix[np.where(etiquetas_unicas_true == true_label)[0][0],
        #                       np.where(etiquetas_unicas_pred == pred_label)[0][0]] += 1
                
        #     # CAMBIO NUMEROS POR CODIGOS DE ERROR
        #     y_pred_changed = y_pred.astype(str)
        #     for i in range(len(etiquetas_unicas_true)):
        #         label = np.argmax(confus_matrix[i])
        #         rep = len(np.where(confus_matrix[i] == np.max(confus_matrix[i]))[0])
        #         for label in range(rep):
        #             index = np.where(confus_matrix[i] == np.max(confus_matrix[i]))[0][label]
        #             if type(etiquetas_unicas_pred[index]) == numpy.int64:
        #                 y_pred_changed[y_pred==etiquetas_unicas_pred[index]]=etiquetas_unicas_true[i]       
                          
        #     etiquetas_unicas_pred = np.unique(y_pred_changed[2*cal_n_traces:2*cal_n_traces+stop_index])
            
        #     # Encontrar valores únicos en array_a_anadir que no están en array_referencia
        #     valores_nuevos = np.setdiff1d(etiquetas_unicas_true, etiquetas_unicas_pred)
            
        #     # Añadir los valores únicos al array original
        #     etiquetas_unicas_pred = np.union1d(etiquetas_unicas_pred, valores_nuevos)
        #     etiquetas_unicas_pred = np.roll(etiquetas_unicas_pred, -np.where(etiquetas_unicas_pred=='E0101')[0])
            
        #     # Crea una matriz de confusión manualmente
        #     confus_matrix = np.zeros((len(etiquetas_unicas_true), len(etiquetas_unicas_pred)))
            
        #     for true_label, pred_label in zip(bugs_entries_list, y_pred_changed[2*cal_n_traces:2*cal_n_traces+stop_index]):
        #         confus_matrix[np.where(etiquetas_unicas_true == true_label)[0][0],
        #                       np.where(etiquetas_unicas_pred == pred_label)[0][0]] += 1
            
        #     # Crea la visualización de la matriz de confusión con el número de instancias
        #     plt.imshow(confus_matrix, cmap=plt.get_cmap('GnBu'), interpolation='nearest')
            
        #     # Etiqueta los cuadrados con el número de instancias
        #     for i in range(len(etiquetas_unicas_true)):
        #         for j in range(len(etiquetas_unicas_pred)):
        #             plt.text(j, i, str(int(confus_matrix[i, j])),
        #                       ha="center", va="center", color="black")
            
        #     plt.title('Matriz de Confusión for {} elements ({})' .format(stop_index, kind))
        #     plt.colorbar()
            
        #     # Etiqueta los ejes
        #     plt.xticks(np.arange(len(etiquetas_unicas_pred)), etiquetas_unicas_pred)
        #     plt.xticks(rotation=90)
        #     plt.yticks(np.arange(len(etiquetas_unicas_true)), etiquetas_unicas_true)
            
        #     # Etiquetas para los ejes
        #     plt.xlabel('Etiquetas Predichas')
            
        #     # Etiqueta para el eje y (en vertical)
        #     plt.ylabel('Etiquetas Reales', rotation=90, verticalalignment='center')
            
        #     plt.show()
        #     break
        # r = r+1
        # # FINISH SLIDING WINDOW
        
    #plotting the results: 
    # y_mod = np.copy(y_pred)
    # y_mod[y_mod==-1] = 9999
    # y_pred[y_pred==-1] = 9999
    # y_mod[:cal_n_traces] = np.argmax(np.bincount(y_pred[:cal_n_traces]))
    # y_mod[cal_n_traces:2*cal_n_traces] = np.argmax(np.bincount(y_pred[cal_n_traces:2*cal_n_traces]))
    # unique, counts = numpy.unique(y_mod, return_counts=True)
    unique, counts = numpy.unique(y_pred, return_counts=True)
    print("DBSCAN CLUSTERS:", dict(zip(unique, counts)))
    
    # Calculate Silhouette Score
    silh_score[index-1] = silhouette_score(data, db.labels_)
    
    # Calculate Calinski-Harabasz Score
    calinski_score[index-1] = calinski_harabasz_score(data, db.labels_)
    
    # Calculate Davies-Bouldin Score
    davies_score[index-1] = davies_bouldin_score(data, db.labels_)
    
    # Calculate S_Dbw Score
    sdbw_score[index-1] = S_Dbw(data, db.labels_, method='Halkidi', metric='euclidean')
        
    # plt.figure(figsize=(16,8), dpi=80)
    fig, ax1 = plt.subplots()
    x = np.linspace(2*cal_n_traces+1, 2*cal_n_traces+stop_index, stop_index)
    lns1 = plt.plot(x, silh_score[:stop_index], '-^b', label='Silhouette score')
    lns2 = plt.plot(x, davies_score[:stop_index], '--g', label='Davies-Bouldin score')   
    plt.xlabel("Number of elements per cluster")
    ax1.set_ylabel("Score", color='b')
    
    ax2 = ax1.twinx()
    lns3 = plt.plot(x, calinski_score[:stop_index], ':r', label='Calinski-Harabasz score')
    ax2.set_ylabel("Score", color='r')
    
    lns4 = plt.plot(x, sdbw_score[:stop_index], 'k', label='S_Dbw score') 
    
    
    plt.title("Clustering convergence score ({})" .format(kind))
    ax1.grid(True)
    lns = lns1+lns2+lns3+lns4
    labs = [l.get_label() for l in lns]
    plt.legend(lns, labs, loc='best')
    ax1.tick_params(axis='y', colors='g')
    ax2.tick_params(axis='y', colors='r')
    # ax1.set_xticklabels(ax1.get_xticks(), rotation=90)
    # ax2.set_xticklabels(ax2.get_xticks(), rotation=90)
    # plt.xticks(x, rotation=90)
    plt.savefig(save_path + device + "_entries_list_" + date + "_CLUST_SCORES_" + kind + ".png", bbox_inches='tight', dpi=100)
    plt.show()
    
    # labs = [l.get_label() for l in lns]
    # plt.title("S_Dbw score")
    # plt.ylabel("Score")
    # plt.xlabel("Number of elements per cluster")
    # plt.grid()
    # # plt.legend(lns4, labs, loc=0)
    # plt.savefig("GUI_elements/sdbw_score" + date + ".png")
    # plt.show()
    

    unique, counts = numpy.unique(np.array(entries_list), return_counts=True)
    # unique_int = unique.astype(int)
    print("REAL ENTRIES:", dict(zip(unique, counts)))
    
    # exec_cluster = np.argmax(np.bincount(y_pred[:cal_n_traces]))
    # exec_index = np.where(y_pred[:cal_n_traces]==exec_cluster)
    # correct_execs = np.shape(exec_index)[1]
    # bug_detector_coefficient = 0.6*correct_execs/cal_n_traces
    
    # if stop_index != np.nan:
    #     for entry in unique:
    #         indices = np.where(np.array(entries_list)==entry)[0]
    #         indices = np.array([indice for indice in indices if indice < stop_index-1])
    #         if len(indices)>0:
    #             print("Entry: {} -> \t {}" .format(entry, stop_labels[2*cal_n_traces+indices]))
    #             bug_trigger = np.count_nonzero(stop_labels[2*cal_n_traces+indices] != exec_cluster)/np.shape(stop_labels[2*cal_n_traces+indices])[0]
    #             if bug_trigger >= bug_detector_coefficient:
    #                 print("YES")
    #             else:
    #                 print("NO")

            
    # else:
        # for entry in unique:
        #     for i in np.where(np.array(entries_list)==entry):
        #         print("Entry: {} -> \t {}" .format(entry, y_mod[2*cal_n_traces+i]))
        #         bug_trigger = np.count_nonzero(y_mod[2*cal_n_traces+i]!=exec_cluster)/np.shape(y_mod[2*cal_n_traces+i])[0]
        #         if bug_trigger>=bug_detector_coefficient:
        #             print("YES")
        #         else:
        #             print("NO")
                
         
    print("FINAL RESULTS")
    
    # number_entries_list = [mapeo_strings[valor] for valor in entries_list]
    bugs_entries_list = [mapeo_bugs[valor] for valor in entries_list]

    # Obtén las etiquetas únicas de ambos arrays
    etiquetas_unicas_true = np.unique(bugs_entries_list)            
    etiquetas_unicas_pred = np.unique(y_pred[2*cal_n_traces:])
    
    # Crea una matriz de confusión manualmente
    confus_matrix = np.zeros((len(etiquetas_unicas_true), len(etiquetas_unicas_pred)))
    
    for true_label, pred_label in zip(bugs_entries_list, y_pred[2*cal_n_traces:]):
        confus_matrix[np.where(etiquetas_unicas_true == true_label)[0][0],
                      np.where(etiquetas_unicas_pred == pred_label)[0][0]] += 1
    
    # CAMBIO NUMEROS POR CODIGOS DE ERROR
    y_pred_changed = np.copy(y_pred).astype(str)
    # Crea un diccionario para mapear predicciones a etiquetas mayoritarias
    mapping_dict = {}
    
    for i in range(len(etiquetas_unicas_true)):
        # Obtiene la etiqueta mayoritaria para la clase actual (i)
        majority_label_index = np.argmax(confus_matrix[i])
        majority_label = etiquetas_unicas_pred[majority_label_index]
        
        # Agrega la correspondencia al diccionario
        mapping_dict[str(majority_label)] = etiquetas_unicas_true[i]
        
    # Reemplaza los valores en y_pred_changed con las etiquetas mayoritarias
    for i in range(len(y_pred_changed)):
        current_label = y_pred_changed[i]
        if current_label in mapping_dict:
            y_pred_changed[i] = mapping_dict[current_label]
                  
    etiquetas_unicas_pred = np.unique(y_pred_changed[2*cal_n_traces:])
    
    # Encontrar valores únicos en array_a_anadir que no están en array_referencia
    valores_nuevos = np.setdiff1d(etiquetas_unicas_true, etiquetas_unicas_pred)
    
    # Añadir los valores únicos al array original
    etiquetas_unicas_pred = np.union1d(etiquetas_unicas_pred, valores_nuevos)
    etiquetas_unicas_pred = np.roll(etiquetas_unicas_pred, -np.where(etiquetas_unicas_pred=='E0101')[0])
    
    # Crea una matriz de confusión manualmente
    confus_matrix = np.zeros((len(etiquetas_unicas_true), len(etiquetas_unicas_pred)))
    
    for true_label, pred_label in zip(bugs_entries_list, y_pred_changed[2*cal_n_traces:]):
        confus_matrix[np.where(etiquetas_unicas_true == true_label)[0][0],
                      np.where(etiquetas_unicas_pred == pred_label)[0][0]] += 1
    
    # Crear la visualización de la matriz de confusión con el número de instancias
    plt.figure(figsize=(20, 12), dpi=100)
    im = plt.imshow(confus_matrix, cmap=plt.get_cmap('GnBu'), interpolation='nearest')
    
    
    # Etiqueta los cuadrados con el número de instancias
    for i in range(len(etiquetas_unicas_true)):
        for j in range(len(etiquetas_unicas_pred)):
            if int(confus_matrix[i,j])>=10:
                plt.text(j, i, str(int(confus_matrix[i, j])),
             ha="center", va="center", color="white", fontsize=22)
            else:
                plt.text(j, i, str(int(confus_matrix[i, j])),
                     ha="center", va="center", color="black", fontsize=22)
    
    plt.title('Confusion Matrix ({}), {},\nFrequency Domain in {} (Serial Port)' .format(kind, get_class_name(db), device), fontsize=25)
    
    cbar = plt.colorbar(im,fraction=0.04, pad=0.04)
    
    # Ajustar el tamaño de fuente del colorbar
    cbar.ax.tick_params(labelsize=20)
    
    # Etiqueta los ejes
    plt.xticks(np.arange(len(etiquetas_unicas_pred)), etiquetas_unicas_pred) 
    plt.xticks(rotation=90)
    plt.yticks(np.arange(len(etiquetas_unicas_true)), etiquetas_unicas_true)
    plt.tick_params(axis='both', which='major', labelsize=25)
    
    # Etiquetas para los ejes
    plt.xlabel('Predicted Labels', fontsize=25)
    plt.ylabel('Real Labels', rotation=90, verticalalignment='center', fontsize=25)
    
    plt.savefig(save_path + device + "_entries_list_" + date + "_CONFUSION_MATRIX_FREQDOMAIN_SERIALPORT" + str(get_class_name(db)) + "_" + kind + ".png", bbox_inches='tight', dpi=100)
    
    plt.show()
    
    # SQUARE CONFUSION MATRIX
    
    # Crear el array "y_pred_outliers"
    y_pred_outliers = np.copy(y_pred_changed)
    
    # Detectar clusters predichos no presentes en etiquetas_unicas_true
    valores_nuevos = np.setdiff1d(etiquetas_unicas_pred, etiquetas_unicas_true)
    
    # Agrupar clusters en "Outliers"
    for valor_nuevo in valores_nuevos:
        y_pred_outliers[y_pred_outliers == valor_nuevo] = "Outliers"
        
    # Detectar clusters predichos no presentes en etiquetas_unicas_outliers
    etiquetas_unicas_outliers = np.unique(y_pred_outliers[2*cal_n_traces:])
    valores_nuevos = np.setdiff1d(etiquetas_unicas_true, etiquetas_unicas_outliers)
            
    # Añadir los valores únicos al array original
    etiquetas_unicas_outliers = np.union1d(etiquetas_unicas_outliers, valores_nuevos)
    etiquetas_unicas_outliers = np.roll(etiquetas_unicas_outliers, -np.where(etiquetas_unicas_outliers=='E0101')[0])
    
    # Modificar la visualización de la matriz de confusión
    etiquetas_unicas_outliers = np.append(etiquetas_unicas_outliers, "Outliers")
    
    posicion_outlier = np.where(etiquetas_unicas_outliers == "Outliers")[0][0]
    etiquetas_unicas_outliers = np.delete(etiquetas_unicas_outliers, posicion_outlier)
   
    # Crea una matriz de confusión manualmente
    confus_matrix = np.zeros((len(etiquetas_unicas_true), len(etiquetas_unicas_outliers)))
    
    for true_label, pred_label in zip(bugs_entries_list, y_pred_outliers[2*cal_n_traces:]):
        confus_matrix[np.where(etiquetas_unicas_true == true_label)[0][0],
                      np.where(etiquetas_unicas_outliers == pred_label)[0][0]] += 1
    
    # Crear la visualización de la matriz de confusión con el número de instancias
    plt.figure(figsize=(9, 9), dpi=100)
    im = plt.imshow(confus_matrix, cmap=plt.get_cmap('GnBu'), interpolation='nearest')
    
    
    # Etiqueta los cuadrados con el número de instancias
    for i in range(len(etiquetas_unicas_true)):
        for j in range(len(etiquetas_unicas_outliers)):
            if int(confus_matrix[i,j])>=10:
                plt.text(j, i, str(int(confus_matrix[i, j])),
             ha="center", va="center", color="white", fontsize=22)
            else:
                plt.text(j, i, str(int(confus_matrix[i, j])),
                     ha="center", va="center", color="black", fontsize=22)
    
    plt.title('Confusion Matrix ({}), {},\nFrequency Domain in {} (Serial Port)' .format(kind, get_class_name(db), device), fontsize=25)
    
    cbar = plt.colorbar(im,fraction=0.04, pad=0.04)
    
    # Ajustar el tamaño de fuente del colorbar
    cbar.ax.tick_params(labelsize=20)
    
    # Etiqueta los ejes
    plt.xticks(np.arange(len(etiquetas_unicas_outliers)), etiquetas_unicas_outliers) 
    plt.xticks(rotation=90)
    plt.yticks(np.arange(len(etiquetas_unicas_true)), etiquetas_unicas_true)
    plt.tick_params(axis='both', which='major', labelsize=25)
    
    # Etiquetas para los ejes
    plt.xlabel('Predicted Labels', fontsize=25)
    plt.ylabel('Real Labels', rotation=90, verticalalignment='center', fontsize=25)
    
    plt.savefig(save_path + device + "_entries_list_" + date + "_CONFUSION_MATRIX_FREQDOMAIN_SERIALPORT_SQUARE" + str(get_class_name(db)) + "_" + kind + ".png", bbox_inches='tight', dpi=100)
    
    plt.show()
    
    # MATRIX ERROR/NO ERROR  
    categorias_no_error = ["SUT00I", "SUT00F"]

    y_pred_error = []
    for pred in y_pred_outliers:
        if pred != "Outliers":
            if pred in categorias_no_error:
                y_pred_error.append("Calibration")
            else:
                y_pred_error.append("Error")
        else:
            y_pred_error.append("Outliers")
            
    bugs_entries_error = []
    for pred in bugs_entries_list:  
        if pred in categorias_no_error:
            bugs_entries_error.append("Calibration")
        else:
            bugs_entries_error.append("Error")
            
    etiquetas_unicas_true = np.unique(bugs_entries_error)
    etiquetas_unicas_true = np.roll(etiquetas_unicas_true, -np.where(etiquetas_unicas_true=='Calibration')[0])
    
    etiquetas_unicas_errors = np.unique(y_pred_error[2*cal_n_traces:])    
    etiquetas_unicas_errors = np.roll(etiquetas_unicas_errors, -np.where(etiquetas_unicas_errors=='Calibration')[0])
        
    # Crea una matriz de confusión manualmente
    confus_matrix = np.zeros((len(etiquetas_unicas_true), len(etiquetas_unicas_errors)))
    
    for true_label, pred_label in zip(bugs_entries_error, y_pred_error[2*cal_n_traces:]):
        confus_matrix[np.where(etiquetas_unicas_true == true_label)[0][0],
                      np.where(etiquetas_unicas_errors == pred_label)[0][0]] += 1
    
    # Crear la visualización de la matriz de confusión con el número de instancias
    plt.figure(figsize=(12, 12), dpi=100)
    plt.imshow(confus_matrix, cmap=plt.get_cmap('GnBu'), interpolation='nearest')
    
    # Etiqueta los cuadrados con el número de instancias
    for i in range(len(etiquetas_unicas_true)):
        for j in range(len(etiquetas_unicas_errors)):
            plt.text(j, i, str(int(confus_matrix[i, j])),
                     ha="center", va="center", color="black", fontsize=30)
    
    plt.title('Confusion Matrix ({}), {},\nFrequency Domain in {} (Serial Port)' .format(kind, get_class_name(db), device), fontsize=35)
    
    # Etiqueta los ejes
    plt.xticks(np.arange(len(etiquetas_unicas_errors)), etiquetas_unicas_errors) 
    plt.xticks(rotation=90)
    plt.yticks(np.arange(len(etiquetas_unicas_true)), etiquetas_unicas_true)
    plt.tick_params(axis='both', which='major', labelsize=30)
    
    # Etiquetas para los ejes
    plt.xlabel('Predicted Labels', fontsize=30)
    plt.ylabel('Real Labels', rotation=90, verticalalignment='center', fontsize=30)
    
    plt.savefig(save_path + device + "_entries_list_" + date + "_CONFUSION_MATRIX_FREQDOMAIN_SERIALPORT_ERROR_NOERROR" + str(get_class_name(db)) + "_" + kind + ".png", bbox_inches='tight', dpi=100)
    
    plt.show()
    
    # MATRIX ARITH/MEMORY ERROR
    categorias_no_error = ["E0101", "E0102", "E0103", "E0104", "E0105", "E0106"]
    
    y_pred_error = []
    for pred in y_pred_outliers:
        if pred != "Outliers":
            if pred == "SUT00F" or pred == "SUT00I":
                y_pred_error.append("Calibration")
            elif pred in categorias_no_error:
                y_pred_error.append("Arithmetic Error")
            else:
                y_pred_error.append("Memory Error")
        else:
            y_pred_error.append("Outliers")
    
    bugs_entries_error = []
    for pred in bugs_entries_list:  
        if pred == "SUT00F" or pred == "SUT00I":
            bugs_entries_error.append("Calibration")
        elif pred in categorias_no_error:
            bugs_entries_error.append("Arithmetic Error")
        else:
            bugs_entries_error.append("Memory Error")
    
    etiquetas_unicas_true = pd.unique(bugs_entries_error)
    etiquetas_unicas_true = np.roll(etiquetas_unicas_true, -np.where(etiquetas_unicas_true=='Arithmetic Error')[0])
    
    # etiquetas_unicas_errors = pd.unique(y_pred_error[2*cal_n_traces:])    
    # etiquetas_unicas_errors = np.roll(etiquetas_unicas_errors, -np.where(etiquetas_unicas_errors=='Arithmetic Error')[0])
    etiquetas_unicas_errors = np.array(['Arithmetic Error', 'Memory Error', 'Calibration', 'Outliers'], dtype=object)
    
    # Crea una matriz de confusión manualmente
    confus_matrix = np.zeros((len(etiquetas_unicas_true), len(etiquetas_unicas_errors)))
    
    for true_label, pred_label in zip(bugs_entries_error, y_pred_error[2*cal_n_traces:]):
        confus_matrix[np.where(etiquetas_unicas_true == true_label)[0][0],
                      np.where(etiquetas_unicas_errors == pred_label)[0][0]] += 1
    
    # Crear la visualización de la matriz de confusión con el número de instancias
    plt.figure(figsize=(12, 12), dpi=100)
    plt.imshow(confus_matrix, cmap=plt.get_cmap('GnBu'), interpolation='nearest')
    
    # Etiqueta los cuadrados con el número de instancias
    for i in range(len(etiquetas_unicas_true)):
        for j in range(len(etiquetas_unicas_errors)):
            if int(confus_matrix[i,j]>=50):
                plt.text(j, i, str(int(confus_matrix[i, j])), ha="center", va="center", color="white", fontsize=45)
            else:
                plt.text(j, i, str(int(confus_matrix[i, j])), ha="center", va="center", color="black", fontsize=45)
    
    plt.title('Confusion Matrix ({}), {},\nFrequency Domain in {} (Serial)' .format(kind, get_class_name(db), device), fontsize=35)
    
    # Etiqueta los ejes
    plt.xticks(np.arange(len(etiquetas_unicas_errors)), etiquetas_unicas_errors) 
    plt.xticks(rotation=45)
    plt.yticks(np.arange(len(etiquetas_unicas_true)), etiquetas_unicas_true)
    plt.tick_params(axis='both', which='major', labelsize=30)
    
    # Etiquetas para los ejes
    plt.xlabel('Predicted Labels', fontsize=40)
    plt.ylabel('Real Labels', rotation=90, verticalalignment='center', fontsize=40)
    
    plt.savefig(save_path + device + "_entries_list_" + date + "_CONFUSION_MATRIX_FREQDOMAIN_SERIALPORT_ARITH_MEMORY" + str(get_class_name(db)) + "_" + kind + ".png", bbox_inches='tight', dpi=100)
    
    plt.show()
    
    
    
    # generar_pitido()
    
    # Definir la paleta de colores categóricos
    categorical_colors = sns.color_palette("tab20")
    
    # Crear el scatterplot
    fig = plt.figure(figsize=(10, 15), dpi=100)
    ax = fig.add_subplot(projection='3d')
    
    # Establecer la misma transparencia para todos los puntos
    alpha_value = 0.8
    
    # Crear leyendas personalizadas agrupadas por colores
    sorted_labels = sorted(set(y_pred_changed[2*cal_n_traces+1:]))
    legend_elements = []
    
    # Filtrar etiquetas que contienen solo letras y aquellas que son numéricas
    string_labels = [label for label in sorted_labels if any(char.isalpha() for char in label)]
    numeric_labels = [label for label in sorted_labels if label.isdigit()]
    
    # Asignar colores distintos a cada etiqueta no numérica
    for i in range(len(string_labels)):
        label = string_labels[i]
        color = categorical_colors[i % len(categorical_colors)]
        legend_elements.append(Line2D([0], [0], marker='o', color='w', markerfacecolor=color, markersize=10, label=label, alpha=alpha_value))
    
    # Agregar las leyendas al gráfico solo si hay elementos en la lista
    if legend_elements:
        ax.legend(handles=legend_elements, title='Clusters', fontsize=20)
    
    # Crear el scatterplot para cada conjunto de datos
    for i in range(2*cal_n_traces+1, len(y_pred)):
        label = y_pred_changed[i]
        x_val = data[i, int(np.round(np.shape(pca_samples)[1]/2)-1)]
        y_val = data[i, int(np.round(np.shape(pca_samples)[1]/2))]
        z_val = data[i, int(np.round(np.shape(pca_samples)[1]/2)+1)]
    
        # Obtener el índice del color categórico correspondiente
        if label in string_labels:
            color_index = string_labels.index(label)
            color = categorical_colors[color_index]
        else:
            color = 'gray'  # Color gris para valores numéricos no encontrados en string_labels
    
        # Crear el scatterplot con el argumento color en lugar de c
        ax.scatter(x_val, y_val, z_val, zdir='y', color=color, s=25, marker="o", alpha=alpha_value)
    
    # Ajustar propiedades de la leyenda
    ax.get_legend().get_title().set_fontsize(20)
    
    # Configurar etiquetas de los ejes y título
    plt.tick_params(axis='both', which='major', labelsize=20)
    ax.set_xlabel('$X$', fontsize=20)
    ax.set_ylabel('$Y$', fontsize=20)
    ax.set_zlabel('$Z$', fontsize=20, rotation=0)
    plt.title("Clustering considering {} elements ({}), {},\nFrequency Domain in {} (Serial Port)".format(n_traces, kind, str(get_class_name(db)), device), fontsize=25)
    
    # Guardar la figura y mostrar
    plt.savefig(save_path + device + "_entries_list_" + date + "_" + str(get_class_name(db)) + kind + ".png", bbox_inches='tight', dpi=100)
    plt.show()
    
    # GENERATE FFMPEG VIDEO FROM CLUSTERING FRAMES
    # ffmpeg.input(path + '/*.jpg', pattern_type='glob', framerate=5).output(ffmpeg_path +'DBSCAN_clustering_results_' + date + '.mp4', vcodec='libx264').run(quiet=True)
    
    print("Silhouette: {}, Calinski-Harabasz: {}, Davies-Bouldin: {}, S_Dbw: {}" .format(silh_score[-1], calinski_score[-1], davies_score[-1], sdbw_score[-1]))
      
def fft_clustering(kind):
    global pca_samples
    global mapeo_bugs
    global entries_list
    global device
    global save_path
    global cal_n_traces
    global n_traces
    global y_pred
    global ffts
    global etiquetas_unicas_true
    global etiquetas_unicas_pred
    global y_pred_changed
     
    labels = [0 for x in range(np.shape(pca_samples)[0])]
    ffts = [[0 for y in range(int(np.shape(pca_samples)[0]/2+1))] for x in range(np.shape(pca_samples)[0])]
    
    for i in range(np.shape(pca_samples)[0]):
        ffts[i] = fft(pca_samples[i])
        labels[i]=np.argmax(ffts[i][1:])
    y_pred = np.copy(labels)
    
    print("FINAL RESULTS")
    
    # number_entries_list = [mapeo_strings[valor] for valor in entries_list]
    bugs_entries_list = [mapeo_bugs[valor] for valor in entries_list]

    # Obtén las etiquetas únicas de ambos arrays
    etiquetas_unicas_true = np.unique(bugs_entries_list)            
    etiquetas_unicas_pred = np.unique(y_pred[2*cal_n_traces:])
    
    # Crea una matriz de confusión manualmente
    confus_matrix = np.zeros((len(etiquetas_unicas_true), len(etiquetas_unicas_pred)))
    
    for true_label, pred_label in zip(bugs_entries_list, y_pred[2*cal_n_traces:]):
        confus_matrix[np.where(etiquetas_unicas_true == true_label)[0][0],
                      np.where(etiquetas_unicas_pred == pred_label)[0][0]] += 1
    
    # CAMBIO NUMEROS POR CODIGOS DE ERROR
    y_pred_changed = np.copy(y_pred).astype(str)
    for i in range(len(etiquetas_unicas_true)):
      # Find all unique predicted classes for this true class (using counts)
      unique_pred_counts = confus_matrix[i]
      unique_predicted_classes = etiquetas_unicas_pred[unique_pred_counts > 0]

      # Update labels for each unique predicted class
      for pred_class in unique_predicted_classes:
        # Find indices of entries with this predicted class
        matching_indices = np.where(y_pred == pred_class)[0]
        # Update labels in y_pred_changed for matching indices
        y_pred_changed[matching_indices] = etiquetas_unicas_true[i]                    
                  
    etiquetas_unicas_pred = np.unique(y_pred_changed[2*cal_n_traces:])
    
    # Encontrar valores únicos en array_a_anadir que no están en array_referencia
    valores_nuevos = np.setdiff1d(etiquetas_unicas_true, etiquetas_unicas_pred)
    
    # Añadir los valores únicos al array original
    etiquetas_unicas_pred = np.union1d(etiquetas_unicas_pred, valores_nuevos)
    etiquetas_unicas_pred = np.roll(etiquetas_unicas_pred, -np.where(etiquetas_unicas_pred=='E0101')[0])
    
    # Crea una matriz de confusión manualmente
    confus_matrix = np.zeros((len(etiquetas_unicas_true), len(etiquetas_unicas_pred)))
    
    for true_label, pred_label in zip(bugs_entries_list, y_pred_changed[2*cal_n_traces:]):
        confus_matrix[np.where(etiquetas_unicas_true == true_label)[0][0],
                      np.where(etiquetas_unicas_pred == pred_label)[0][0]] += 1
    
    # Crear la visualización de la matriz de confusión con el número de instancias
    plt.figure(figsize=(20, 12), dpi=100)
    im = plt.imshow(confus_matrix, cmap=plt.get_cmap('GnBu'), interpolation='nearest')
    
    
    # Etiqueta los cuadrados con el número de instancias
    for i in range(len(etiquetas_unicas_true)):
        for j in range(len(etiquetas_unicas_pred)):
            if int(confus_matrix[i,j])>=10:
                plt.text(j, i, str(int(confus_matrix[i, j])),
             ha="center", va="center", color="white", fontsize=22)
            else:
                plt.text(j, i, str(int(confus_matrix[i, j])),
                     ha="center", va="center", color="black", fontsize=22)
    
    plt.title('Confusion Matrix ({}), \nFrequency Domain in {}' .format(kind, device), fontsize=25)
    
    cbar = plt.colorbar(im,fraction=0.04, pad=0.04)
    
    # Ajustar el tamaño de fuente del colorbar
    cbar.ax.tick_params(labelsize=20)
    
    # Etiqueta los ejes
    plt.xticks(np.arange(len(etiquetas_unicas_pred)), etiquetas_unicas_pred) 
    plt.xticks(rotation=90)
    plt.yticks(np.arange(len(etiquetas_unicas_true)), etiquetas_unicas_true)
    plt.tick_params(axis='both', which='major', labelsize=25)
    
    # Etiquetas para los ejes
    plt.xlabel('Predicted Labels', fontsize=25)
    plt.ylabel('Real Labels', rotation=90, verticalalignment='center', fontsize=25)
    
    plt.savefig(save_path + device + "_entries_list_" + date + "_CONFUSION_MATRIX_FREQDOMAIN_" + kind + ".png", bbox_inches='tight', dpi=100)
    
    plt.show()
    
    # SQUARE CONFUSION MATRIX
    
    # Crear el array "y_pred_outliers"
    y_pred_outliers = np.copy(y_pred_changed)
    
    # Detectar clusters predichos no presentes en etiquetas_unicas_true
    valores_nuevos = np.setdiff1d(etiquetas_unicas_pred, etiquetas_unicas_true)
    
    # Agrupar clusters en "Outliers"
    for valor_nuevo in valores_nuevos:
        y_pred_outliers[y_pred_outliers == valor_nuevo] = "Outliers"
        
    # Detectar clusters predichos no presentes en etiquetas_unicas_outliers
    etiquetas_unicas_outliers = np.unique(y_pred_outliers[2*cal_n_traces:])
    valores_nuevos = np.setdiff1d(etiquetas_unicas_true, etiquetas_unicas_outliers)
            
    # Añadir los valores únicos al array original
    etiquetas_unicas_outliers = np.union1d(etiquetas_unicas_outliers, valores_nuevos)
    etiquetas_unicas_outliers = np.roll(etiquetas_unicas_outliers, -np.where(etiquetas_unicas_outliers=='E0101')[0])
    
    # Modificar la visualización de la matriz de confusión
    etiquetas_unicas_outliers = np.append(etiquetas_unicas_outliers, "Outliers")
    
    posicion_outlier = np.where(etiquetas_unicas_outliers == "Outliers")[0][0]
    etiquetas_unicas_outliers = np.delete(etiquetas_unicas_outliers, posicion_outlier)
   
    # Crea una matriz de confusión manualmente
    confus_matrix = np.zeros((len(etiquetas_unicas_true), len(etiquetas_unicas_outliers)))
    
    for true_label, pred_label in zip(bugs_entries_list, y_pred_outliers[2*cal_n_traces:]):
        confus_matrix[np.where(etiquetas_unicas_true == true_label)[0][0],
                      np.where(etiquetas_unicas_outliers == pred_label)[0][0]] += 1
    
    # Crear la visualización de la matriz de confusión con el número de instancias
    plt.figure(figsize=(9, 9), dpi=100)
    im = plt.imshow(confus_matrix, cmap=plt.get_cmap('GnBu'), interpolation='nearest')
    
    
    # Etiqueta los cuadrados con el número de instancias
    for i in range(len(etiquetas_unicas_true)):
        for j in range(len(etiquetas_unicas_outliers)):
            if int(confus_matrix[i,j])>=10:
                plt.text(j, i, str(int(confus_matrix[i, j])),
             ha="center", va="center", color="white", fontsize=22)
            else:
                plt.text(j, i, str(int(confus_matrix[i, j])),
                     ha="center", va="center", color="black", fontsize=22)
    
    plt.title('Confusion Matrix ({}),\nFrequency Domain in {}' .format(kind, device), fontsize=25)
    
    cbar = plt.colorbar(im,fraction=0.04, pad=0.04)
    
    # Ajustar el tamaño de fuente del colorbar
    cbar.ax.tick_params(labelsize=20)
    
    # Etiqueta los ejes
    plt.xticks(np.arange(len(etiquetas_unicas_outliers)), etiquetas_unicas_outliers) 
    plt.xticks(rotation=90)
    plt.yticks(np.arange(len(etiquetas_unicas_true)), etiquetas_unicas_true)
    plt.tick_params(axis='both', which='major', labelsize=25)
    
    # Etiquetas para los ejes
    plt.xlabel('Predicted Labels', fontsize=25)
    plt.ylabel('Real Labels', rotation=90, verticalalignment='center', fontsize=25)
    
    plt.savefig(save_path + device + "_entries_list_" + date + "_CONFUSION_MATRIX_FREQDOMAIN_SQUARE_" + kind + ".png", bbox_inches='tight', dpi=100)
    
    plt.show()
    
    # MATRIX ERROR/NO ERROR  
    categorias_no_error = ["SUT00I", "SUT00F"]

    y_pred_error = []
    for pred in y_pred_outliers:
        if pred != "Outliers":
            if pred in categorias_no_error:
                y_pred_error.append("Calibration")
            else:
                y_pred_error.append("Error")
        else:
            y_pred_error.append("Outliers")
            
    bugs_entries_error = []
    for pred in bugs_entries_list:  
        if pred in categorias_no_error:
            bugs_entries_error.append("Calibration")
        else:
            bugs_entries_error.append("Error")
            
    etiquetas_unicas_true = np.unique(bugs_entries_error)
    etiquetas_unicas_true = np.roll(etiquetas_unicas_true, -np.where(etiquetas_unicas_true=='Calibration')[0])
    
    etiquetas_unicas_errors = np.unique(y_pred_error[2*cal_n_traces:])    
    etiquetas_unicas_errors = np.roll(etiquetas_unicas_errors, -np.where(etiquetas_unicas_errors=='Calibration')[0])
        
    # Crea una matriz de confusión manualmente
    confus_matrix = np.zeros((len(etiquetas_unicas_true), len(etiquetas_unicas_errors)))
    
    for true_label, pred_label in zip(bugs_entries_error, y_pred_error[2*cal_n_traces:]):
        confus_matrix[np.where(etiquetas_unicas_true == true_label)[0][0],
                      np.where(etiquetas_unicas_errors == pred_label)[0][0]] += 1
    
    # Crear la visualización de la matriz de confusión con el número de instancias
    plt.figure(figsize=(12, 12), dpi=100)
    plt.imshow(confus_matrix, cmap=plt.get_cmap('GnBu'), interpolation='nearest')
    
    # Etiqueta los cuadrados con el número de instancias
    for i in range(len(etiquetas_unicas_true)):
        for j in range(len(etiquetas_unicas_errors)):
            plt.text(j, i, str(int(confus_matrix[i, j])),
                     ha="center", va="center", color="black", fontsize=30)
    
    plt.title('Confusion Matrix ({}), \nFrequency Domain in {}' .format(kind, device), fontsize=35)
    
    # Etiqueta los ejes
    plt.xticks(np.arange(len(etiquetas_unicas_errors)), etiquetas_unicas_errors) 
    plt.xticks(rotation=90)
    plt.yticks(np.arange(len(etiquetas_unicas_true)), etiquetas_unicas_true)
    plt.tick_params(axis='both', which='major', labelsize=30)
    
    # Etiquetas para los ejes
    plt.xlabel('Predicted Labels', fontsize=30)
    plt.ylabel('Real Labels', rotation=90, verticalalignment='center', fontsize=30)
    
    plt.savefig(save_path + device + "_entries_list_" + date + "_CONFUSION_MATRIX_FREQDOMAIN_ERROR_NOERROR_" + kind + ".png", bbox_inches='tight', dpi=100)
    
    plt.show()
    
    # MATRIX ARITH/MEMORY ERROR
    categorias_no_error = ["E0101", "E0102", "E0103", "E0104", "E0105", "E0106"]
    
    y_pred_error = []
    for pred in y_pred_outliers:
        if pred != "Outliers":
            if pred == "SUT00F" or pred == "SUT00I":
                y_pred_error.append("Calibration")
            elif pred in categorias_no_error:
                y_pred_error.append("Arithmetic Error")
            else:
                y_pred_error.append("Memory Error")
        else:
            y_pred_error.append("Outliers")
    
    bugs_entries_error = []
    for pred in bugs_entries_list:  
        if pred == "SUT00F" or pred == "SUT00I":
            bugs_entries_error.append("Calibration")
        elif pred in categorias_no_error:
            bugs_entries_error.append("Arithmetic Error")
        else:
            bugs_entries_error.append("Memory Error")
    
    etiquetas_unicas_true = pd.unique(bugs_entries_error)
    etiquetas_unicas_true = np.roll(etiquetas_unicas_true, -np.where(etiquetas_unicas_true=='Arithmetic Error')[0])
    
    # etiquetas_unicas_errors = pd.unique(y_pred_error[2*cal_n_traces:])    
    # etiquetas_unicas_errors = np.roll(etiquetas_unicas_errors, -np.where(etiquetas_unicas_errors=='Arithmetic Error')[0])
    etiquetas_unicas_errors = np.array(['Arithmetic Error', 'Memory Error', 'Calibration', 'Outliers'], dtype=object)
    
    # Crea una matriz de confusión manualmente
    confus_matrix = np.zeros((len(etiquetas_unicas_true), len(etiquetas_unicas_errors)))
    
    for true_label, pred_label in zip(bugs_entries_error, y_pred_error[2*cal_n_traces:]):
        confus_matrix[np.where(etiquetas_unicas_true == true_label)[0][0],
                      np.where(etiquetas_unicas_errors == pred_label)[0][0]] += 1
    
    # Crear la visualización de la matriz de confusión con el número de instancias
    plt.figure(figsize=(12, 12), dpi=100)
    plt.imshow(confus_matrix, cmap=plt.get_cmap('GnBu'), interpolation='nearest')
    
    # Etiqueta los cuadrados con el número de instancias
    for i in range(len(etiquetas_unicas_true)):
        for j in range(len(etiquetas_unicas_errors)):
            if int(confus_matrix[i,j]>=50):
                plt.text(j, i, str(int(confus_matrix[i, j])), ha="center", va="center", color="white", fontsize=45)
            else:
                plt.text(j, i, str(int(confus_matrix[i, j])), ha="center", va="center", color="black", fontsize=45)
    
    plt.title('Confusion Matrix ({}),\nFrequency Domain in {}' .format(kind, device), fontsize=35)
    
    # Etiqueta los ejes
    plt.xticks(np.arange(len(etiquetas_unicas_errors)), etiquetas_unicas_errors) 
    plt.xticks(rotation=45)
    plt.yticks(np.arange(len(etiquetas_unicas_true)), etiquetas_unicas_true)
    plt.tick_params(axis='both', which='major', labelsize=30)
    
    # Etiquetas para los ejes
    plt.xlabel('Predicted Labels', fontsize=40)
    plt.ylabel('Real Labels', rotation=90, verticalalignment='center', fontsize=40)
    
    plt.savefig(save_path + device + "_entries_list_" + date + "_CONFUSION_MATRIX_FREQDOMAIN_ARITH_MEMORY_" + kind + ".png", bbox_inches='tight', dpi=100)
    
    plt.show()
    
    
    
    # generar_pitido()
    
    # Definir la paleta de colores categóricos
    categorical_colors = sns.color_palette("tab20")
    
    # Crear el scatterplot
    fig = plt.figure(figsize=(10, 15), dpi=100)
    ax = fig.add_subplot(projection='3d')
    
    # Establecer la misma transparencia para todos los puntos
    alpha_value = 0.8
    
    # Crear leyendas personalizadas agrupadas por colores
    sorted_labels = sorted(set(y_pred_changed[2*cal_n_traces+1:]))
    legend_elements = []
    
    # Filtrar etiquetas que contienen solo letras y aquellas que son numéricas
    string_labels = [label for label in sorted_labels if any(char.isalpha() for char in label)]
    numeric_labels = [label for label in sorted_labels if label.isdigit()]
    
    # Asignar colores distintos a cada etiqueta no numérica
    for i in range(len(string_labels)):
        label = string_labels[i]
        color = categorical_colors[i % len(categorical_colors)]
        legend_elements.append(Line2D([0], [0], marker='o', color='w', markerfacecolor=color, markersize=10, label=label, alpha=alpha_value))
    
    # Agregar las leyendas al gráfico solo si hay elementos en la lista
    if legend_elements:
        ax.legend(handles=legend_elements, title='Clusters', fontsize=20)
    
    # Crear el scatterplot para cada conjunto de datos
    for i in range(2*cal_n_traces+1, len(y_pred)):
        label = y_pred_changed[i]
        x_val = data[i, int(np.round(np.shape(pca_samples)[1]/2)-1)]
        y_val = data[i, int(np.round(np.shape(pca_samples)[1]/2))]
        z_val = data[i, int(np.round(np.shape(pca_samples)[1]/2)+1)]
    
        # Obtener el índice del color categórico correspondiente
        if label in string_labels:
            color_index = string_labels.index(label)
            color = categorical_colors[color_index]
        else:
            color = 'gray'  # Color gris para valores numéricos no encontrados en string_labels
    
        # Crear el scatterplot con el argumento color en lugar de c
        ax.scatter(x_val, y_val, z_val, zdir='y', color=color, s=25, marker="o", alpha=alpha_value)
    
    # Ajustar propiedades de la leyenda
    ax.get_legend().get_title().set_fontsize(20)
    
    # Configurar etiquetas de los ejes y título
    plt.tick_params(axis='both', which='major', labelsize=20)
    ax.set_xlabel('$X$', fontsize=20)
    ax.set_ylabel('$Y$', fontsize=20)
    ax.set_zlabel('$Z$', fontsize=20, rotation=0)
    plt.title("Clustering considering {} elements ({}),\nFrequency Domain in {}" .format(n_traces, kind, device), fontsize=25)
    
    # Guardar la figura y mostrar
    plt.savefig(save_path + device + "_entries_list_" + date + "_" + kind + ".png", bbox_inches='tight', dpi=100)
    plt.show()
    
    # GENERATE FFMPEG VIDEO FROM CLUSTERING FRAMES
    # ffmpeg.input(path + '/*.jpg', pattern_type='glob', framerate=5).output(ffmpeg_path +'DBSCAN_clustering_results_' + date + '.mp4', vcodec='libx264').run(quiet=True)
    
    print("Silhouette: {}, Calinski-Harabasz: {}, Davies-Bouldin: {}, S_Dbw: {}" .format(silh_score[-1], calinski_score[-1], davies_score[-1], sdbw_score[-1]))
    

def operation(kind):
    
    global calibration_path
    global entries_path
    global root
    global details
    global clust
    global silh
    global pca_plot
    global imp_model
    global ip_address
    global port_list
    global channel
    global n_traces
    global n_samples
    global command_OP
    global input_signal
    global date
    global command
    global device
    global robust_samples  
    
    exec_name = [filename for filename in os.listdir(calibration_path) if filename.startswith(device + "_exec_")][0]
    noexec_name = [filename for filename in os.listdir(calibration_path) if filename.startswith(device + "_noexec")][0]
    fuzz_name = device + "_EM_bugs_" + date + ".csv"
    
    EM_signal = np.loadtxt(calibration_path + "/" + exec_name,delimiter=',')
    EM_cal_traces = np.shape(EM_signal)[0]
    n_samples = np.shape(EM_signal)[1]
    
    # cut_n_samples=int(n_samples/2)
    # n_samples = int(cut_n_samples/2+1)
    input_signal = np.array([[[0 for z in range(n_samples)] for y in range(n_traces)] for x in range(n_files)], dtype=float)
    # input_signal[0][:EM_cal_traces] = np.abs(fft(np.loadtxt(calibration_path + "/" + exec_name,delimiter=',')))
    # input_signal[1][:EM_cal_traces] = np.abs(fft(np.loadtxt(calibration_path + "/" + noexec_name, delimiter=',')))
    # input_signal[2] = np.abs(fft(np.loadtxt(results_entries_path + fuzz_name, delimiter=',')))
     
    input_signal[0][:EM_cal_traces] = np.loadtxt(calibration_path + "/" + exec_name,delimiter=',')
    input_signal[1][:EM_cal_traces] = np.loadtxt(calibration_path + "/" + noexec_name, delimiter=',')
    input_signal[2] = np.loadtxt(results_entries_path + fuzz_name, delimiter=',')
        
    for i in range(3):
        if i < 2:
            for j in range(EM_cal_traces):
                input_signal[i][j] = apply_filter(input_signal[i][j], "gaussian", {"sigma": 2.0})
        if i == 2:
            for j in range(np.shape(input_signal)[1]):
                input_signal[i][j] = apply_filter(input_signal[i][j], "gaussian", {"sigma": 2.0})
    
    print("Entries signals files: ", fuzz_name)
        
    outlier_detection(kind)   
    # robust_covariance_procedure(kind)
    # pca_components = [int(0.05*n_traces), int(0.1*n_traces), int(0.25*n_traces), int(0.5*n_traces), int(0.75*n_traces), int(n_traces)]
    # for i in pca_components:
    # outlied_signal = np.copy(input_signal)
    robust_samples = np.copy(outlied_signal)
    pca_technique_application(kind)
    clustering_procedure(kind)
    # fft_clustering(kind)
    return

def bugs_capture():
    
    global pinata_ip
    global date    
    global entries_path

    entries_list = list(map(str,random.choices(input_info, k=n_traces)))
    now = datetime.datetime.now()
    date_arr = [str(now.day), str(now.month), str(now.year), str(now.hour), str(now.minute)]
    date_arr = [x.zfill(2) for x in date_arr]
    date = date_arr[0] + "_" + date_arr[1] + "_" + date_arr[2] + "_" + date_arr[3] + "o" + date_arr[4]
    with open(entries_path + "entries_list_" + date + '.csv', 'w') as txt_file:
        for line in entries_list:
            txt_file.write(line + "\n")
    os.system(entries_command + str(n_traces) + " " + str("entries_list_" + date + '.csv'))
    
def calibration(ssh):
    global calibration_command
    global cal_n_traces
    global device
    
    # CALIBRATION SIGNALS CAPTURE
    cal_command = "python3.11 /home/atenea/ATENEA_Calibration_Clustering/bbb_default_calibration.py "
    command = "a1"
    calibration_command = command
    os.system(cal_command + command + " " + str(cal_n_traces) + " " + device)
    print(ssh_stdout.read().decode())
    print(time.time()-start, "seconds to get calibration samples")
    
def entries_list_creation(entries):
    global entries_list
    global list_nfs_path
    global date
    global device
    
    # input_info = entries.split(',')
    # Array para almacenar 20 repeticiones de cada string
    entries_list = []

    # Repetir cada string 20 veces y añadirlo al nuevo array
    for string in entries:
        repeated_string = [string] * 20
        entries_list.extend(repeated_string)
            
    now = datetime.datetime.now()
    date_arr = [str(now.day), str(now.month), str(now.year), str(now.hour), str(now.minute)]
    date_arr = [x.zfill(2) for x in date_arr]
    date = date_arr[2] + "_" + date_arr[1] + "_" + date_arr[0] + "_" + date_arr[3] + "o" + date_arr[4]

    with open(entries_path + device + "_entries_list_" + date + '.csv', 'w') as txt_file:
        for line in entries_list:
            txt_file.write(line + "\n")
            
    print("Entries list created: ", device, '_entries_list_', date, '.csv')

start1 = time.time()
# CALIBRATION SIGNALS CAPTURE
# cal_command = "python3.11 data_calibration.py "
# command = "a1"
# os.system(cal_command)
# print(time.time()-start, "seconds to get calibration samples")

start = time.time()
# FUZZING ENTRIES SIGNALS CAPTURE
entries_command = "python3.11 data_collection.py "
# entries = "10,11,12,13,14,15,16,29"
# entries = "-10,15,213123123123,-12312313213"
# input_info = entries.split(',')
cal_n_traces = 100
# calibration()

kind = "EM"

for it in range(n_fuzz):
    it_start = time.time()
    print("ITERATION", it+1)
    # bugs_capture() # BUGS CAPTURING
    entries = list(mapeo_bugs.keys())
    # entries_list_creation(entries)
    
    with open(entries_path + device + "_entries_list_" + date + '.csv') as file:
        entries_list = [line.rstrip() for line in file]
    
    n_traces = np.shape(entries_list)[0]
    n_tests = int(np.sqrt(n_traces))
    
    operation(kind) # DATA PROCESSING + CLUSTERING
    print(time.time()-it_start, "seconds to perform fuzzing iteration", it+1)           
    
print(time.time()-start, "seconds to perform operation")
print(time.time()-start1, "seconds to perform whole process")    


